#!/usr/bin/perl

use warnings;
use strict;

use Data::Dump::Streamer;
use lib '/usr/src/norisbank';
use Finance::Bank::Norisbank;
use Time::Local;

my $nbank = Finance::Bank::Norisbank->new('7967197003', '46613', 
    sub {shift; print "Status callback: ", @_, "\n"});

print $nbank->{page}, "\n";

my $thingies = [$nbank->get_transactions(
    [4,1], [4,20]
    )];

Dump($thingies);

# Dump($nbank);
